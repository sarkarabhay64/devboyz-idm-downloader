# Code of Conduct

Contributors and maintainers are expected to be respectful in issues, pull
requests, discussions, and support conversations.

## Expected

- Stay on technical topics and use inclusive language.
- Assume good intent; disagree with ideas, not people.
- Protect other people’s privacy. Never share cookies, tokens, signed media
  URLs, browser profiles, or `.awesome-downloader` contents.

## Unacceptable

- Harassment, hate speech, or personal attacks.
- Publishing others’ private data.
- Asking anyone to disable security tools or to bypass DRM.

## Enforcement

The maintainers may edit or remove violating content and may refuse to work with
people who ignore this policy. Security vulnerabilities should be reported as
described in [SECURITY.md](SECURITY.md), not in a public issue with exploit
details.

This project is independently maintained by Devboyz. Original Awesome Downloader
contributors remain credited for their work; this policy applies to the Devboyz
distribution’s collaboration spaces.

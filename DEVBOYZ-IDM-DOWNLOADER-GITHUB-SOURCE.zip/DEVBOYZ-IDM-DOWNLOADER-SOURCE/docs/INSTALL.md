# Install and use DEVBOYZ IDM DOWNLOADER

This is preview software. YouTube speed and compatibility vary. Native ARM
builds are not provided.

## Ubuntu 22.04, 64-bit Intel/AMD

### Install the `.deb` package

Use the artifact produced by `npm run dist:linux`:

`release/DEVBOYZ-IDM-DOWNLOADER-0.2.0-preview.1-amd64.deb`

```bash
sudo apt install ./DEVBOYZ-IDM-DOWNLOADER-0.2.0-preview.1-amd64.deb
```

Launch **DEVBOYZ IDM DOWNLOADER** from the application menu. The executable name
is `devboyz-idm-downloader`. You do not need Node.js for a packaged install.

Uninstall with `sudo apt remove devboyz-idm-downloader`. Downloaded files and
`~/.awesome-downloader` are left in place.

### Run the AppImage

```bash
chmod +x DEVBOYZ-IDM-DOWNLOADER-0.2.0-preview.1-x86_64.AppImage
./DEVBOYZ-IDM-DOWNLOADER-0.2.0-preview.1-x86_64.AppImage
```

Ubuntu 22.04 typically provides `libfuse2`, which AppImage runtimes expect. If
launch fails because FUSE is missing, either install `libfuse2` or use
`--appimage-extract-and-run`.

## Enable video buttons (Chrome / Edge)

The browser extension is optional. Direct HTTP(S) downloads work without it.

The extension adds **Download this video** buttons to supported web videos. Until
a browser-store listing is published, add it once to each browser you use:

1. Open **Browser integration** in DEVBOYZ IDM DOWNLOADER.
2. Click **Copy extension folder path**.
3. Click **Open Chrome extensions** or **Open Edge extensions**.
4. Turn on **Developer mode**, then **Load unpacked**, and select the copied
   extension folder (the folder that contains `manifest.json`).
5. Confirm **DEVBOYZ IDM DOWNLOADER Integration** is enabled.
6. Return to the app and wait for the connection message, then refresh the video
   page.

Linux native-messaging manifests are written under the browser
`NativeMessagingHosts` directories. **Linux browser capture has not been
verified end-to-end in this distribution.**

The data directory remains `.awesome-downloader` in your home folder so existing
history is not abandoned. A packaged copy typically exposes the extension at
`~/.awesome-downloader/BrowserIntegration/extension`.

Firefox does not yet have equivalent verified YouTube support. Do not attach
browser profiles, tokens, or `.awesome-downloader` contents to bug reports.

## Download a file or video

- For a file link, use **Add URL** in the app.
- For a supported video, play it briefly, click **Download this video**, and
  select a quality. Only download content you are permitted to save.
- In **Download File Info**, choose a name, folder, and category. Choose
  **Start Download**, **Download Later**, or **Cancel**.

Closing the main window keeps the app in the tray. Use **Tasks → Exit** to quit.
DRM, private/sign-in-required videos, and live streams are not supported.

## Support

Maintained by Devboyz. WhatsApp: +91 81580 36375 —
[https://wa.me/918158036375](https://wa.me/918158036375)

The in-app **Help → WhatsApp support** item opens that link in your default
browser. It does not send your download list or files.

## Updates and uninstall

Quit the app before installing a newer package. After updating, reload the
browser extension if you use it.

There is no automatic updater yet.

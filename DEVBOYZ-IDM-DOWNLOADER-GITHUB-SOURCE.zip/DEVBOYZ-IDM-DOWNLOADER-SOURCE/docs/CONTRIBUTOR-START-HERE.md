# Contributor start here

DEVBOYZ IDM DOWNLOADER is an early preview maintained by Devboyz. It originated
from [Awesome Downloader](https://github.com/Ahmadkhattak1/awesome-downloader).
Linux x64 desktop packaging is part of this distribution; that does not mean
every Linux desktop environment or every browser has been verified.

Downloads and optional Chrome/Edge integration exist, but reliability, sustained
speed and user experience still need work. macOS, Windows ARM64, broader browser
support and playlists remain development goals unless a later release documents
them as tested.

## Our strategy

Keep working Linux downloads reliable while adding capabilities in small,
reviewed steps. Measure speed improvements and verify completed files. This
distribution’s supported packaging target is Ubuntu 22.04 x64.

The maintainer approves scope and merges PRs. An approved issue approves an
objective; it does not approve every possible implementation or guarantee a
merge. Propose additional features in an issue before implementing them.

## Pick your first task

1. Read the relevant goal and its acceptance criteria in the issue tracker of
   the published Devboyz repository (when available). Upstream Awesome Downloader
   issues remain useful historical context at
   [Ahmadkhattak1/awesome-downloader](https://github.com/Ahmadkhattak1/awesome-downloader/issues).
2. Choose a concrete implementation step. Check its prerequisites, existing PRs
   and comments so you do not duplicate another contributor's work.
3. Comment with the step you want to take, your approach, and how you will test
   it. State which operating systems/devices you can actually test.
4. Wait for maintainer agreement on scope and ownership before starting new
   feature implementation.
5. Submit a focused PR with test evidence.

Small bug reports, documentation corrections and regression tests are welcome.

## What the labels mean

| Label | Meaning | What to do |
| --- | --- | --- |
| `type: goal` | A larger outcome delivered through several steps | Read it for context; choose a linked implementation issue |
| `status: ready` | No unfinished implementation prerequisite is recorded | Propose your approach and agree ownership |
| `status: blocked` | A named prerequisite must merge and pass validation first | Follow that dependency; planning is welcome |
| `help wanted` | Contributions are welcome | Still check readiness and discuss scope |
| `bug` / `enhancement` / `documentation` | The kind of work | These do not indicate priority or merge approval |
| `good first issue` | A deliberately scoped newcomer task, when applied | Read its acceptance criteria before claiming it |

## Evidence and review

- Add regression coverage for behavior you change and explain what you tested.
- Distinguish fixtures, live-browser testing and real-device testing. A passing
  build does not establish support for an operating system or architecture.
- Preserve transfer integrity, audio/video pairing, cancellation, credential
  boundaries, and existing Linux download behavior.
- Keep credentials, signed media URLs and browser profiles out of public reports.

See [CONTRIBUTING.md](../CONTRIBUTING.md) for development commands,
[SECURITY.md](../SECURITY.md) for private vulnerability reports, and
[release requirements](RELEASING.md) for distribution checks.

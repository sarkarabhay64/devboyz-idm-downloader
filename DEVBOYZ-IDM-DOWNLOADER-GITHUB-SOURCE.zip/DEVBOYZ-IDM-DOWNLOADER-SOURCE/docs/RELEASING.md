# Release checklist

Public source and public binaries are separate release steps. Do not publish a
download asset just because a local package command succeeds. Do not push to
GitHub or attach release assets until the maintainer explicitly approves
publication.

1. Run `npm ci` and `npm test` on the OS you will ship.
2. Review the source diff for private data and proprietary material.
3. Verify third-party license notices and provide corresponding source and build
   material for the actual bundled GPL binaries (including their linked components).
   The FFmpeg commit alone is not a complete source bundle for its external libraries.
   Mirror required source archives alongside binary release assets. Record hashes.
   Review the yt-dlp executable's bundled components too if it is included.
4. Linux: `npm run dist:linux` or `bash scripts/build-linux.sh` builds an
   unsigned x64 AppImage and `.deb`. Test both on Ubuntu 22.04 without Node.js:
   install or launch, add a permitted HTTP(S) URL, pause/resume if the server
   allows ranges, complete, and quit.
5. This distribution does not produce Windows installers. Do not attach Windows
   binaries to a Linux-only release.
6. Create the GitHub-ready source ZIP with `bash scripts/pack-github-source.sh`,
   then `bash scripts/assemble-release.sh` to collect packages, checksums, and
   notes in `~/Downloads/DEVBOYZ-IDM-DOWNLOADER-RELEASE/`.
7. When the maintainer publishes, attach Linux packages, checksums, notices, and
   required source assets. GitHub Actions currently **upload Linux build
   artifacts**; they do not create a GitHub Release or push to a store.
8. Never attach research, browser profiles, diagnostics with media URLs, or user data.
9. Enable repository Issues and private vulnerability reporting on the Devboyz
   repository after it is created. Do not push this fork to
   `Ahmadkhattak1/awesome-downloader`.

Current gates: GitHub authentication, dependency source-distribution audit,
clean-machine installer QA, and first Devboyz release publication. Code signing
and browser store publication are not configured. Do not advertise them as
available.

Intended future repository: `https://github.com/devboyz/idm-downloader`
(proposal only until that remote exists).

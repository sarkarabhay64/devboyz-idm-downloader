#!/usr/bin/env bash
# Build unsigned Linux x64 .deb and AppImage packages from a clean install.
set -euo pipefail
cd "$(dirname -- "$0")/.."

if ! command -v node >/dev/null; then
  echo "Node.js 22+ is required." >&2
  exit 1
fi

npm ci
npm test
npm run dist:linux

echo
echo "Linux packages (if the build succeeded):"
ls -l release/DEVBOYZ-IDM-DOWNLOADER-*-amd64.deb release/DEVBOYZ-IDM-DOWNLOADER-*-x86_64.AppImage

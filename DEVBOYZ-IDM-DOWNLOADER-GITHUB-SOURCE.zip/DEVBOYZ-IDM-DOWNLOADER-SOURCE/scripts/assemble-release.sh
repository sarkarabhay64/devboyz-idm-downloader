#!/usr/bin/env bash
# Copy Linux packages, source ZIP, checksums, and notes into the release folder.
set -euo pipefail
cd "$(dirname -- "$0")/.."
VERSION="$(node -p "require('./package.json').version")"
DEB="release/DEVBOYZ-IDM-DOWNLOADER-${VERSION}-amd64.deb"
APPIMAGE="release/DEVBOYZ-IDM-DOWNLOADER-${VERSION}-x86_64.AppImage"
ZIP="${ZIP:-$HOME/Downloads/DEVBOYZ-IDM-DOWNLOADER-GITHUB-SOURCE.zip}"
DEST="${DEST:-$HOME/Downloads/DEVBOYZ-IDM-DOWNLOADER-RELEASE}"

if [[ ! -f "$DEB" ]]; then
  echo "Missing $DEB. Run npm run dist:linux first." >&2
  exit 1
fi
if [[ ! -f "$APPIMAGE" ]]; then
  echo "Missing $APPIMAGE. Run npm run dist:linux first." >&2
  exit 1
fi
if [[ ! -f "$ZIP" ]]; then
  echo "Missing $ZIP. Run bash scripts/pack-github-source.sh first." >&2
  exit 1
fi

rm -rf "$DEST"
mkdir -p "$DEST"
cp -a "$DEB" "$DEST/"
cp -a "$APPIMAGE" "$DEST/"
cp -a "$ZIP" "$DEST/"

DEB_NAME="$(basename -- "$DEB")"
APP_NAME="$(basename -- "$APPIMAGE")"
ZIP_NAME="$(basename -- "$ZIP")"

cat > "$DEST/README.txt" <<EOF
DEVBOYZ IDM DOWNLOADER ${VERSION} — Linux x86_64 release files

This application is an independent open-source download manager. It is not
affiliated with Internet Download Manager.

Ubuntu users: install ${DEB_NAME}

  sudo apt install ./${DEB_NAME}

Then open DEVBOYZ IDM DOWNLOADER from the application menu, or run
devboyz-idm-downloader.

Portable Linux: ${APP_NAME}

  chmod +x ${APP_NAME}
  ./${APP_NAME}

AppImage typically needs libfuse2 on Ubuntu 22.04. If FUSE is missing:

  ./${APP_NAME} --appimage-extract-and-run

Source for GitHub: ${ZIP_NAME}
Unpacks to DEVBOYZ-IDM-DOWNLOADER-SOURCE/.

Verify checksums:

  sha256sum -c SHA256SUMS.txt

Uninstall the Debian package with sudo apt remove devboyz-idm-downloader.
That does not delete ~/.awesome-downloader or files you downloaded.

Need help? https://wa.me/918158036375
EOF

cat > "$DEST/RELEASE-NOTES.md" <<EOF
# DEVBOYZ IDM DOWNLOADER ${VERSION}

Independent Linux x86_64 desktop download manager maintained by Devboyz.

This is a modified distribution of
[Awesome Downloader](https://github.com/Ahmadkhattak1/awesome-downloader)
by Ahmadkhattak1 and contributors. Original code remains MIT-licensed.
Devboyz added Linux compatibility, Linux packages, branding, documentation,
and WhatsApp support entry points. This product is not affiliated with
Internet Download Manager.

## Packages in this folder

- \`${DEB_NAME}\` — Debian/Ubuntu amd64 installer
- \`${APP_NAME}\` — portable AppImage
- \`${ZIP_NAME}\` — GitHub-ready source tree (no \`node_modules\`, no \`.git\`)

## Changes relative to the upstream desktop app

- Linux startup no longer invokes the Windows C# compiler (\`csc.exe\`).
- Native messaging on Linux uses a POSIX wrapper and XDG manifest paths.
- User data remains in \`~/.awesome-downloader\`.
- Native messaging host name remains \`com.awesome.downloader\`.
- Linux x64 \`.deb\` and AppImage packaging.
- Application name DEVBOYZ IDM DOWNLOADER.
- Help/About WhatsApp support link (\`https://wa.me/918158036375\`) opens only
  after an explicit click and does not send download history.

## Limitations

- Preview software. DRM, private/sign-in-required media, and live streams are
  unsupported.
- Linux Chrome/Edge/Firefox capture is implemented but not claimed as fully
  verified end-to-end in this release.
- Packages are unsigned. There is no automatic updater.
- This folder does not include Windows installers.

## License

MIT for original project code, plus third-party notices in THIRD-PARTY.md
(including GPL-covered FFmpeg components bundled by ffmpeg-static).
EOF

(
  cd "$DEST"
  sha256sum "$DEB_NAME" "$APP_NAME" "$ZIP_NAME" > SHA256SUMS.txt
  sha256sum -c SHA256SUMS.txt
)

echo "Release directory: $DEST"
ls -lh "$DEST"

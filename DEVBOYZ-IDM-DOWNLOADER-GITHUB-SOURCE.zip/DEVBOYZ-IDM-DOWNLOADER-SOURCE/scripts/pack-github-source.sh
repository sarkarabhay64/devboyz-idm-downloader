#!/usr/bin/env bash
# Create a clean GitHub-ready source ZIP with one root directory.
set -euo pipefail
cd "$(dirname -- "$0")/.."
ROOT="$(pwd)"
VERSION="$(node -p "require('./package.json').version")"
STAGE="${STAGE:-$HOME/Downloads/DEVBOYZ-IDM-DOWNLOADER-SOURCE}"
ZIP="${ZIP:-$HOME/Downloads/DEVBOYZ-IDM-DOWNLOADER-GITHUB-SOURCE.zip}"

rm -rf "$STAGE"
mkdir -p "$STAGE"

rsync -a \
  --exclude '.git/' \
  --exclude 'node_modules/' \
  --exclude 'release/' \
  --exclude 'release-*/' \
  --exclude 'linux-unpacked/' \
  --exclude 'coverage/' \
  --exclude 'test-results/' \
  --exclude '.playwright-cli/' \
  --exclude 'research/' \
  --exclude '.local-evidence/' \
  --exclude '*.log' \
  --exclude '*.dmp' \
  --exclude '*.pem' \
  --exclude '*.pfx' \
  --exclude '*.key' \
  --exclude '.env' \
  --exclude '.env.*' \
  --exclude 'integration/native-host' \
  --exclude 'integration/native-host.exe' \
  --exclude 'integration/native-host.cmd' \
  --exclude 'integration/runtime-path.txt' \
  --exclude 'integration/desktop-launch.json' \
  --exclude 'vendor/*.exe' \
  --exclude 'DEVBOYZ-IDM-DOWNLOADER-SOURCE/' \
  --exclude 'DEVBOYZ-IDM-DOWNLOADER-RELEASE/' \
  --exclude 'DEVBOYZ-IDM-DOWNLOADER-GITHUB-SOURCE.zip' \
  ./ "$STAGE/"

# Confirm required files exist before zipping.
for required in package.json package-lock.json README.md LICENSE THIRD-PARTY.md CONTRIBUTING.md CODE_OF_CONDUCT.md SECURITY.md .gitignore desktop/main.cjs desktop/branding.cjs desktop/platform.cjs renderer/index.html scripts/build-linux.sh .github/workflows/test.yml .github/workflows/linux-build.yml; do
  if [[ ! -e "$STAGE/$required" ]]; then
    echo "Missing required source file: $required" >&2
    exit 1
  fi
done

if [[ -d "$STAGE/node_modules" ]]; then
  echo "Refusing to ZIP node_modules." >&2
  exit 1
fi

rm -f "$ZIP"
(
  cd "$(dirname -- "$STAGE")"
  zip -r -q "$ZIP" "$(basename -- "$STAGE")"
)

echo "Source directory: $STAGE"
echo "Source ZIP: $ZIP ($VERSION)"
set +o pipefail
unzip -l "$ZIP" | sed -n '1,40p'
echo "..."
unzip -l "$ZIP" | tail -n 1
set -o pipefail

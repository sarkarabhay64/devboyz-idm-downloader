# Security

Do not include signed media URLs, cookies, authorization headers, native messaging
payloads, browser profile files, or `.awesome-downloader` contents in public issues.

For vulnerabilities, use GitHub's private vulnerability reporting feature if it
is enabled on the published Devboyz repository. If it is unavailable, open a
minimal issue asking for a private reporting channel without publishing
exploitation details or secrets.

The native bridge must remain authenticated and loopback-only. No DRM bypass,
credential harvesting, or page-controlled filesystem paths are accepted.

WhatsApp support is for product help when the user chooses to open
https://wa.me/918158036375. It is not an automatic telemetry channel and must
not be used to send other people’s private data.

Only the latest preview is maintained. There is no automatic updater yet.

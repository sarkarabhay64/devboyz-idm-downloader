const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const branding = require('./branding.cjs');
const { approvedSupportUrl, openApprovedExternal } = require('./external-links.cjs');
const pkg = require('../package.json');
const { isOwnExtensionName } = require('./browser-registration.cjs');

test('user-facing identity is DEVBOYZ IDM DOWNLOADER without renaming storage or native messaging', () => {
  assert.equal(branding.displayName, 'DEVBOYZ IDM DOWNLOADER');
  assert.equal(branding.shortName, 'Devboyz IDM');
  assert.equal(branding.linuxPackageName, 'devboyz-idm-downloader');
  assert.equal(branding.dataDirectoryName, '.awesome-downloader');
  assert.equal(branding.nativeMessagingHost, 'com.awesome.downloader');
  assert.equal(branding.supportUrl, 'https://wa.me/918158036375');
  assert.equal(branding.supportPhoneDisplay, '+91 81580 36375');
  assert.ok(branding.isOwnExtensionName('DEVBOYZ IDM DOWNLOADER Integration'));
  assert.ok(branding.isOwnExtensionName('Awesome Downloader Integration'));
  assert.equal(branding.isOwnExtensionName('Other Extension'), false);
});

test('package metadata matches the Devboyz Linux identifiers', () => {
  assert.equal(pkg.name, 'devboyz-idm-downloader');
  assert.equal(pkg.build.appId, 'in.devboyz.idmdownloader');
  assert.equal(pkg.build.productName, 'DEVBOYZ IDM DOWNLOADER');
  assert.equal(pkg.build.linux.executableName, 'devboyz-idm-downloader');
  assert.equal(pkg.desktopName, 'devboyz-idm-downloader.desktop');
  assert.equal(branding.linuxDesktopFile, 'devboyz-idm-downloader.desktop');
  assert.equal(pkg.build.linux.syncDesktopName, true);
  assert.equal(pkg.build.deb.packageName, 'devboyz-idm-downloader');
  assert.match(pkg.build.deb.artifactName, /DEVBOYZ-IDM-DOWNLOADER-\$\{version\}-amd64\.deb/);
  assert.match(pkg.build.appImage.artifactName, /DEVBOYZ-IDM-DOWNLOADER-\$\{version\}-x86_64\.AppImage/);
  assert.match(pkg.scripts.dist, /--linux AppImage deb/);
  assert.match(pkg.scripts.package, /--linux dir/);
  assert.doesNotMatch(pkg.scripts.dist, /--win /);
});

test('WhatsApp support URL allowlist rejects unapproved destinations', async () => {
  assert.equal(approvedSupportUrl('https://wa.me/918158036375'), 'https://wa.me/918158036375');
  assert.throws(() => approvedSupportUrl('https://wa.me/918158036375/extra'), /Blocked unapproved URL/);
  assert.throws(() => approvedSupportUrl('https://example.com'), /Blocked unapproved URL/);
  assert.throws(() => approvedSupportUrl('http://wa.me/918158036375'), /Only HTTPS/);
  assert.throws(() => approvedSupportUrl('https://evil.wa.me/918158036375'), /Blocked unapproved URL/);
  assert.throws(() => approvedSupportUrl('https://wa.me/918158036375?text=hi'), /Blocked unapproved URL/);
  const opened = [];
  assert.equal(
    await openApprovedExternal('https://wa.me/918158036375', { shell: { openExternal: async href => opened.push(href) } }),
    'https://wa.me/918158036375'
  );
  assert.deepEqual(opened, ['https://wa.me/918158036375']);
  await assert.rejects(
    () => openApprovedExternal('https://example.com', { shell: { openExternal: async () => {} } }),
    /Blocked unapproved URL/
  );
});

test('browser-registration recognizes both current and legacy extension names', () => {
  assert.equal(typeof isOwnExtensionName, 'function');
  assert.equal(isOwnExtensionName('DEVBOYZ IDM DOWNLOADER Integration'), true);
  assert.equal(isOwnExtensionName('Awesome Downloader Integration'), true);
});

test('Linux executable name is used in packaging, not a hardcoded Windows compiler path', () => {
  assert.doesNotMatch(pkg.build.linux.executableName, /csc\.exe|\\\\Windows/);
  assert.equal(path.basename(branding.iconFile), 'app-icon.png');
});

const path = require('node:path');
const pkg = require('../package.json');

const displayName = 'DEVBOYZ IDM DOWNLOADER';
const shortName = 'Devboyz IDM';
const supportUrl = 'https://wa.me/918158036375';
const supportPhoneDisplay = '+91 81580 36375';
const extensionDisplayName = `${displayName} Integration`;
const legacyExtensionDisplayName = 'Awesome Downloader Integration';

function isOwnExtensionName(name) {
  return name === extensionDisplayName || name === legacyExtensionDisplayName;
}

module.exports = {
  displayName,
  shortName,
  maintainer: 'Devboyz',
  version: pkg.version,
  appId: pkg.build?.appId || 'in.devboyz.idmdownloader',
  linuxPackageName: 'devboyz-idm-downloader',
  linuxExecutable: 'devboyz-idm-downloader',
  linuxDesktopFile: 'devboyz-idm-downloader.desktop',
  dataDirectoryName: '.awesome-downloader',
  nativeMessagingHost: 'com.awesome.downloader',
  nativeMessagingDescription: `${displayName} browser bridge`,
  extensionDisplayName,
  legacyExtensionDisplayName,
  isOwnExtensionName,
  supportUrl,
  supportPhoneDisplay,
  supportHost: 'wa.me',
  supportPath: '/918158036375',
  upstreamName: 'Awesome Downloader',
  upstreamUrl: 'https://github.com/Ahmadkhattak1/awesome-downloader',
  intendedRepository: 'https://github.com/devboyz/idm-downloader',
  aboutDetail: [
    `Maintained by Devboyz.`,
    'Independent open-source download manager. Not affiliated with Internet Download Manager.',
    'Originated from Ahmadkhattak1’s Awesome Downloader.',
    'WhatsApp support opens only after you click the button. The app does not send download history or other private data.',
    `WhatsApp: ${supportPhoneDisplay}`
  ].join('\n'),
  iconFile: path.join(__dirname, '..', 'assets', 'app-icon.png')
};

const fs = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const { execFile } = require('node:child_process');
const { promisify } = require('node:util');
const exec = promisify(execFile);
const {
  nativeHostPath,
  windowsNativeHostCompiler,
  nativeMessagingManifestDestinations,
  browserUserDataRoots,
  posixNativeHostScript
} = require('./platform.cjs');
const { nativeMessagingHost, nativeMessagingDescription, isOwnExtensionName } = require('./branding.cjs');

async function writeUtf8IfChanged(filePath, content) {
  let previous;
  try { previous = await fs.readFile(filePath, 'utf8'); } catch (e) { if (e.code !== 'ENOENT') throw e; }
  if (previous === content) return previous;
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  if (previous && previous !== content) {
    const stamp = new Date().toISOString().replaceAll(/[:.]/g, '-');
    await fs.writeFile(`${filePath}.${stamp}.bak`, previous);
  }
  await fs.writeFile(filePath, content, 'utf8');
  return previous;
}

async function registerBrowser({ browser, extensionId }, { dataDirectory, integrationRoot, platform = process.platform, env = process.env, homedir = os.homedir(), exec: run = exec } = {}) {
  if (!['Chrome', 'Edge', 'Firefox'].includes(browser)) throw new Error('Choose Chrome, Edge, or Firefox.');
  if (typeof extensionId !== 'string' || !(browser === 'Firefox' ? /^[A-Za-z0-9@._{}-]{1,128}$/ : /^[a-p]{32}$/).test(extensionId)) throw new Error('Copy the extension ID from your browser’s extensions page.');
  const host = nativeMessagingHost;
  const folder = path.join(dataDirectory, 'NativeMessaging');
  const manifestPath = path.join(folder, `${browser}.json`);
  const hostPath = nativeHostPath(integrationRoot, platform);
  const manifest = { name: host, description: nativeMessagingDescription, path: hostPath, type: 'stdio' };
  if (browser === 'Firefox') manifest.allowed_extensions = [extensionId];
  else manifest.allowed_origins = [`chrome-extension://${extensionId}/`];
  const content = JSON.stringify(manifest, null, 2);
  await fs.access(manifest.path);
  await fs.mkdir(folder, { recursive: true });
  let previous;
  try { previous = await fs.readFile(manifestPath, 'utf8'); } catch (e) { if (e.code !== 'ENOENT') throw e; }
  const stamp = new Date().toISOString().replaceAll(/[:.]/g, '-');
  if (previous && previous !== content) await fs.writeFile(`${manifestPath}.${stamp}.bak`, previous);
  if (platform === 'win32') {
    const roots = { Chrome: 'Google\\Chrome', Edge: 'Microsoft\\Edge', Firefox: 'Mozilla' };
    const key = `HKCU\\Software\\${roots[browser]}\\NativeMessagingHosts\\${host}`;
    let registry = null;
    try { registry = (await run('reg.exe', ['QUERY', key, '/ve'], { windowsHide: true })).stdout; }
    catch (error) { if (error.code !== 1) throw error; }
    const previousPath = registry?.match(/REG_SZ\s+(.+)\r?\n?/)?.[1]?.trim();
    if (registry && previousPath !== manifestPath) await fs.writeFile(path.join(folder, `${browser}.${stamp}.registry-backup.txt`), registry);
    if (previous !== content) await fs.writeFile(manifestPath, content, 'utf8');
    if (previousPath !== manifestPath) await run('reg.exe', ['ADD', key, '/ve', '/t', 'REG_SZ', '/d', manifestPath, '/f'], { windowsHide: true });
  } else {
    if (previous !== content) await fs.writeFile(manifestPath, content, 'utf8');
    for (const destination of nativeMessagingManifestDestinations(browser, { platform, env, homedir })) {
      await writeUtf8IfChanged(destination, content);
    }
  }
  let extensionPath = path.join(integrationRoot, 'extension');
  if (browser === 'Firefox') {
    extensionPath = path.join(folder, 'firefox-extension');
    await fs.cp(path.join(integrationRoot, 'extension'), extensionPath, { recursive: true });
    await fs.copyFile(path.join(extensionPath, 'manifest.firefox.json'), path.join(extensionPath, 'manifest.json'));
  }
  return { ok: true, manifestPath, extensionPath };
}

function samePath(left, right, platform) {
  if (!left || !right) return false;
  return platform === 'win32' ? left.toLowerCase() === right.toLowerCase() : left === right;
}

// Read only extension registrations, never browser history, cookies, or page data.
async function connectInstalledBrowsers({ dataDirectory, integrationRoot, localAppData = process.env.LOCALAPPDATA, platform = process.platform, env = process.env, homedir = os.homedir(), exec: run = exec } = {}) {
  const results = [];
  const roots = browserUserDataRoots({ platform, env, homedir, localAppData });
  for (const { browser, root } of roots) {
    let profiles;
    try { profiles = await fs.readdir(root, { withFileTypes: true }); } catch { continue; }
    const ids = new Set();
    for (const profile of profiles.filter(p => p.isDirectory() && /^(Default|Profile \d+)$/.test(p.name))) {
      for (const file of ['Preferences', 'Secure Preferences']) {
        try {
          const settings = JSON.parse(await fs.readFile(path.join(root, profile.name, file), 'utf8')).extensions?.settings || {};
          for (const [id, entry] of Object.entries(settings)) {
            if (!/^[a-p]{32}$/.test(id) || !entry.path || !path.isAbsolute(entry.path)) continue;
            const installed = await fs.realpath(entry.path).catch(() => null);
            const expected = await fs.realpath(path.join(integrationRoot, 'extension'));
            let ownExtension = samePath(installed, expected, platform);
            if (installed && !ownExtension) {
              const manifest = JSON.parse(await fs.readFile(path.join(installed, 'manifest.json'), 'utf8'));
              const background = await fs.readFile(path.join(installed, 'background.js'), 'utf8');
              ownExtension = isOwnExtensionName(manifest.name) && manifest.background?.service_worker === 'background.js' && background.includes(`const HOST = '${nativeMessagingHost}'`);
            }
            if (ownExtension) ids.add(id);
          }
        } catch { /* A running browser can temporarily replace a preference file. */ }
      }
    }
    if (ids.size) {
      const result = await registerBrowser({ browser, extensionId: [...ids][0] }, { dataDirectory, integrationRoot, platform, env, homedir, exec: run });
      // Multiple profiles may assign different IDs to this same unpacked extension.
      const manifest = JSON.parse(await fs.readFile(result.manifestPath, 'utf8'));
      manifest.allowed_origins = [...ids].map(id => `chrome-extension://${id}/`);
      const content = JSON.stringify(manifest, null, 2);
      await fs.writeFile(result.manifestPath, content, 'utf8');
      if (platform !== 'win32') {
        for (const destination of nativeMessagingManifestDestinations(browser, { platform, env, homedir })) {
          await writeUtf8IfChanged(destination, content);
        }
      }
      results.push({ browser, connected: true });
    }
  }
  return results;
}

async function prepareNativeHost(integrationRoot, executable, { platform = process.platform, env = process.env, exec: run = exec } = {}) {
  const folder = path.join(integrationRoot, 'integration');
  await fs.mkdir(folder, { recursive: true });
  if (platform === 'win32') {
    const target = nativeHostPath(integrationRoot, platform);
    try { await fs.access(target); }
    catch {
      const compiler = windowsNativeHostCompiler({ env });
      await run(compiler, ['/nologo', '/target:exe', `/out:${target}`, path.join(folder, 'NativeHostLauncher.cs')], { windowsHide: true });
    }
  } else {
    const target = nativeHostPath(integrationRoot, platform);
    await fs.writeFile(target, posixNativeHostScript(), { mode: 0o755 });
    await fs.chmod(target, 0o755);
  }
  await fs.writeFile(path.join(folder, 'runtime-path.txt'), executable, 'utf8');
}

module.exports = { registerBrowser, connectInstalledBrowsers, prepareNativeHost, isOwnExtensionName };

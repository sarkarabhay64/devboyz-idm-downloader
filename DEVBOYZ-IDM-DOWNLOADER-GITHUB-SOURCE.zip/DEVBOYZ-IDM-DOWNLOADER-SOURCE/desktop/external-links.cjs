const { supportUrl: defaultSupportUrl } = require('./branding.cjs');

function approvedHttpsUrl(value, allowedUrl) {
  let allowed;
  let parsed;
  try {
    allowed = new URL(allowedUrl);
    parsed = new URL(value);
  } catch {
    throw new Error('Invalid URL.');
  }
  if (allowed.protocol !== 'https:' || parsed.protocol !== 'https:') {
    throw new Error('Only HTTPS support links are allowed.');
  }
  if (parsed.username || parsed.password || allowed.username || allowed.password) {
    throw new Error('Blocked unapproved URL.');
  }
  if (parsed.hostname !== allowed.hostname || parsed.port !== allowed.port) {
    throw new Error('Blocked unapproved URL.');
  }
  if (parsed.pathname !== allowed.pathname || parsed.search !== allowed.search || parsed.hash !== allowed.hash) {
    throw new Error('Blocked unapproved URL.');
  }
  return parsed.href;
}

function approvedSupportUrl(value, { allowedUrl = defaultSupportUrl } = {}) {
  return approvedHttpsUrl(value, allowedUrl);
}

async function openApprovedExternal(url, { shell, allowedUrl = defaultSupportUrl } = {}) {
  if (!shell || typeof shell.openExternal !== 'function') {
    throw new Error('No safe external opener is available.');
  }
  const href = approvedSupportUrl(url, { allowedUrl });
  await shell.openExternal(href);
  return href;
}

module.exports = { approvedHttpsUrl, approvedSupportUrl, openApprovedExternal };

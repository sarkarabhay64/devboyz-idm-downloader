const fs = require('node:fs/promises');
const { spawn } = require('node:child_process');
const { browserExecutableCandidates } = require('./platform.cjs');

async function openExtensions(browser, { platform = process.platform, env = process.env } = {}) {
  const relativeOk = { Chrome: true, Edge: true }[browser];
  if (!relativeOk) throw new Error('Choose Chrome or Edge.');
  const url = browser === 'Chrome' ? 'chrome://extensions/' : 'edge://extensions/';
  for (const executable of browserExecutableCandidates(browser, { platform, env })) {
    try { await fs.access(executable); } catch { continue; }
    await new Promise((resolve, reject) => {
      const child = spawn(executable, [url], { detached: true, stdio: 'ignore', windowsHide: true });
      child.once('error', reject);
      child.once('spawn', () => { child.unref(); resolve(); });
    });
    return;
  }
  throw new Error(`${browser} was not found. Open ${url} in your browser manually.`);
}
module.exports = { openExtensions };

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const {
  nativeHostFileName,
  nativeHostPath,
  windowsNativeHostCompiler,
  nativeMessagingManifestDestinations,
  browserUserDataRoots,
  browserExecutableCandidates,
  openWithCommand,
  youtubeExtractorName,
  youtubeExtractorCandidates,
  firstExisting
} = require('./platform.cjs');
const { prepareNativeHost, registerBrowser, connectInstalledBrowsers } = require('./browser-registration.cjs');

test('Linux uses a posix native host and never points at csc.exe', () => {
  assert.equal(nativeHostFileName('linux'), 'native-host');
  assert.equal(nativeHostPath('/tmp/root', 'linux'), path.join('/tmp/root', 'integration', 'native-host'));
  assert.match(windowsNativeHostCompiler({ env: {} }), /csc\.exe$/);
  assert.doesNotMatch(nativeHostPath('/tmp/root', 'linux'), /csc\.exe|native-host\.exe/);
});

test('Windows native-host path and compiler remain unchanged', () => {
  assert.equal(nativeHostFileName('win32'), 'native-host.exe');
  assert.equal(
    windowsNativeHostCompiler({ env: { WINDIR: 'C:\\Windows' } }),
    path.join('C:\\Windows', 'Microsoft.NET', 'Framework64', 'v4.0.30319', 'csc.exe')
  );
  assert.equal(
    windowsNativeHostCompiler({ env: {} }),
    path.join('C:\\Windows', 'Microsoft.NET', 'Framework64', 'v4.0.30319', 'csc.exe')
  );
  assert.deepEqual(
    openWithCommand('C:\\Users\\a\\file.bin', { platform: 'win32', env: { SystemRoot: 'C:\\Windows' } }),
    { command: path.join('C:\\Windows', 'System32', 'OpenWith.exe'), args: ['C:\\Users\\a\\file.bin'] }
  );
});

test('Linux native messaging and profile roots use XDG paths, not the registry', () => {
  const homedir = '/home/user';
  const env = { XDG_CONFIG_HOME: '/home/user/.config' };
  assert.deepEqual(
    nativeMessagingManifestDestinations('Chrome', { platform: 'linux', env, homedir }),
    [
      path.join('/home/user/.config', 'google-chrome', 'NativeMessagingHosts', 'com.awesome.downloader.json'),
      path.join('/home/user/.config', 'chromium', 'NativeMessagingHosts', 'com.awesome.downloader.json')
    ]
  );
  assert.equal(nativeMessagingManifestDestinations('Chrome', { platform: 'win32', env: {}, homedir }).length, 0);
  assert.deepEqual(
    browserUserDataRoots({ platform: 'linux', env, homedir }),
    [
      { browser: 'Chrome', root: path.join('/home/user/.config', 'google-chrome') },
      { browser: 'Chrome', root: path.join('/home/user/.config', 'chromium') },
      { browser: 'Edge', root: path.join('/home/user/.config', 'microsoft-edge') }
    ]
  );
  assert.deepEqual(
    browserUserDataRoots({ platform: 'win32', env: {}, localAppData: 'C:\\Users\\a\\AppData\\Local' }),
    [
      { browser: 'Chrome', root: path.join('C:\\Users\\a\\AppData\\Local', 'Google', 'Chrome', 'User Data') },
      { browser: 'Edge', root: path.join('C:\\Users\\a\\AppData\\Local', 'Microsoft', 'Edge', 'User Data') }
    ]
  );
});

test('browser executables stay Windows-specific on win32 and PATH-based on Linux', () => {
  const windows = browserExecutableCandidates('Chrome', {
    platform: 'win32',
    env: { LOCALAPPDATA: 'C:\\Users\\a\\AppData\\Local', ProgramFiles: 'C:\\Program Files' }
  });
  assert.ok(windows.some(p => p.endsWith(path.join('Google', 'Chrome', 'Application', 'chrome.exe'))));
  const linux = browserExecutableCandidates('Chrome', { platform: 'linux', env: { PATH: '/opt/bin' } });
  assert.ok(linux.some(p => p.endsWith('google-chrome') || p.endsWith('google-chrome-stable')));
  assert.ok(!linux.some(p => p.endsWith('chrome.exe')));
});

test('Linux Open With uses xdg-open rather than OpenWith.exe', () => {
  assert.deepEqual(openWithCommand('/tmp/file.bin', { platform: 'linux', env: {} }), { command: 'xdg-open', args: ['/tmp/file.bin'] });
});

test('yt-dlp paths are platform-specific for development and packaged builds', () => {
  assert.equal(youtubeExtractorName('win32'), 'yt-dlp.exe');
  assert.equal(youtubeExtractorName('linux'), 'yt-dlp');
  assert.deepEqual(
    youtubeExtractorCandidates({ platform: 'win32', electron: '44.9.0', resourcesPath: 'C:\\App\\resources', defaultApp: false, vendorDirectory: 'C:\\src\\vendor' }),
    [path.join('C:\\App\\resources', 'tools', 'yt-dlp.exe'), path.join('C:\\src\\vendor', 'yt-dlp.exe')]
  );
  assert.deepEqual(
    youtubeExtractorCandidates({ platform: 'linux', electron: '44.9.0', resourcesPath: '/opt/app/resources', defaultApp: false, vendorDirectory: '/src/vendor' }),
    [path.join('/opt/app/resources', 'tools', 'yt-dlp'), path.join('/src/vendor', 'yt-dlp')]
  );
  assert.deepEqual(
    youtubeExtractorCandidates({ platform: 'linux', vendorDirectory: '/src/vendor' }),
    [path.join('/src/vendor', 'yt-dlp')]
  );
});

test('Linux prepareNativeHost writes an executable wrapper and does not spawn csc.exe', async t => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'ad-host-linux-'));
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  const integrationRoot = path.join(root, 'app');
  await fs.mkdir(path.join(integrationRoot, 'integration'), { recursive: true });
  const spawned = [];
  await prepareNativeHost(integrationRoot, '/usr/bin/awesome-downloader', {
    platform: 'linux',
    exec: async (command, args) => { spawned.push({ command, args }); return { stdout: '' }; }
  });
  assert.deepEqual(spawned, []);
  const script = path.join(integrationRoot, 'integration', 'native-host');
  const text = await fs.readFile(script, 'utf8');
  assert.match(text, /^#!\/bin\/sh/);
  assert.match(text, /native-host\.cjs/);
  assert.doesNotMatch(text, /csc\.exe|Framework64|native-host\.exe/);
  assert.equal(await fs.readFile(path.join(integrationRoot, 'integration', 'runtime-path.txt'), 'utf8'), '/usr/bin/awesome-downloader');
  assert.ok((await fs.stat(script)).mode & 0o111);
});

test('Windows prepareNativeHost still compiles native-host.exe with the .NET csc path when missing', async t => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'ad-host-win-'));
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  const integrationRoot = path.join(root, 'app');
  await fs.mkdir(path.join(integrationRoot, 'integration'), { recursive: true });
  await fs.writeFile(path.join(integrationRoot, 'integration', 'NativeHostLauncher.cs'), '// test');
  const spawned = [];
  const compiler = windowsNativeHostCompiler({ env: { WINDIR: 'C:\\Windows' } });
  await prepareNativeHost(integrationRoot, 'C:\\App\\Awesome Downloader.exe', {
    platform: 'win32',
    env: { WINDIR: 'C:\\Windows' },
    exec: async (command, args) => {
      spawned.push({ command, args });
      await fs.writeFile(args.find(a => a.startsWith('/out:')).slice(5), 'fake-exe');
      return { stdout: '' };
    }
  });
  assert.equal(spawned.length, 1);
  assert.equal(spawned[0].command, compiler);
  assert.ok(spawned[0].args.includes('/target:exe'));
  assert.equal(await fs.readFile(path.join(integrationRoot, 'integration', 'runtime-path.txt'), 'utf8'), 'C:\\App\\Awesome Downloader.exe');
});

test('Windows prepareNativeHost does not recompile when native-host.exe already exists', async t => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'ad-host-win-exists-'));
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  const integrationRoot = path.join(root, 'app');
  await fs.mkdir(path.join(integrationRoot, 'integration'), { recursive: true });
  await fs.writeFile(path.join(integrationRoot, 'integration', 'native-host.exe'), 'existing');
  const spawned = [];
  await prepareNativeHost(integrationRoot, 'C:\\App\\Awesome Downloader.exe', {
    platform: 'win32',
    exec: async (command, args) => { spawned.push({ command, args }); return { stdout: '' }; }
  });
  assert.deepEqual(spawned, []);
});

test('Linux browser registration writes native-messaging JSON and never calls reg.exe', async t => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'ad-reg-linux-'));
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  const integrationRoot = path.join(root, 'app');
  const config = path.join(root, 'config');
  await fs.mkdir(path.join(integrationRoot, 'integration'), { recursive: true });
  await fs.mkdir(path.join(integrationRoot, 'extension'), { recursive: true });
  await fs.writeFile(path.join(integrationRoot, 'integration', 'native-host'), '#!/bin/sh\n');
  const spawned = [];
  const result = await registerBrowser(
    { browser: 'Chrome', extensionId: 'abcdefghijklmnopabcdefghijklmnop' },
    {
      dataDirectory: path.join(root, 'data'),
      integrationRoot,
      platform: 'linux',
      env: { XDG_CONFIG_HOME: config },
      homedir: root,
      exec: async (command, args) => { spawned.push({ command, args }); return { stdout: '' }; }
    }
  );
  assert.deepEqual(spawned, []);
  const manifest = JSON.parse(await fs.readFile(result.manifestPath, 'utf8'));
  assert.equal(manifest.path, path.join(integrationRoot, 'integration', 'native-host'));
  assert.deepEqual(manifest.allowed_origins, ['chrome-extension://abcdefghijklmnopabcdefghijklmnop/']);
  const chromeHost = JSON.parse(await fs.readFile(path.join(config, 'google-chrome', 'NativeMessagingHosts', 'com.awesome.downloader.json'), 'utf8'));
  assert.equal(chromeHost.path, manifest.path);
});

test('Windows browser registration still uses HKCU native messaging keys', async t => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'ad-reg-win-'));
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  const integrationRoot = path.join(root, 'app');
  await fs.mkdir(path.join(integrationRoot, 'integration'), { recursive: true });
  await fs.mkdir(path.join(integrationRoot, 'extension'), { recursive: true });
  await fs.writeFile(path.join(integrationRoot, 'integration', 'native-host.exe'), 'exe');
  const spawned = [];
  const result = await registerBrowser(
    { browser: 'Chrome', extensionId: 'abcdefghijklmnopabcdefghijklmnop' },
    {
      dataDirectory: path.join(root, 'data'),
      integrationRoot,
      platform: 'win32',
      exec: async (command, args) => {
        spawned.push({ command, args });
        if (args[0] === 'QUERY') { const error = new Error('not found'); error.code = 1; throw error; }
        return { stdout: '' };
      }
    }
  );
  assert.ok(spawned.some(call => call.command === 'reg.exe' && call.args[0] === 'ADD'));
  assert.ok(spawned.some(call => call.args.includes('HKCU\\Software\\Google\\Chrome\\NativeMessagingHosts\\com.awesome.downloader')));
  const manifest = JSON.parse(await fs.readFile(result.manifestPath, 'utf8'));
  assert.equal(manifest.path, path.join(integrationRoot, 'integration', 'native-host.exe'));
});

test('Linux connectInstalledBrowsers also recognizes the Devboyz extension display name', async t => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'ad-connect-linux-new-'));
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  const integrationRoot = path.join(root, 'app');
  const config = path.join(root, 'config');
  const extension = path.join(integrationRoot, 'extension');
  await fs.mkdir(path.join(integrationRoot, 'integration'), { recursive: true });
  await fs.mkdir(extension, { recursive: true });
  await fs.writeFile(path.join(integrationRoot, 'integration', 'native-host'), '#!/bin/sh\n');
  await fs.writeFile(path.join(extension, 'manifest.json'), JSON.stringify({ name: 'DEVBOYZ IDM DOWNLOADER Integration', background: { service_worker: 'background.js' } }));
  await fs.writeFile(path.join(extension, 'background.js'), "const HOST = 'com.awesome.downloader';\n");
  const profile = path.join(config, 'google-chrome', 'Default');
  await fs.mkdir(profile, { recursive: true });
  await fs.writeFile(path.join(profile, 'Preferences'), JSON.stringify({
    extensions: { settings: { abcdefghijklmnopabcdefghijklmnop: { path: extension } } }
  }));
  const connected = await connectInstalledBrowsers({
    dataDirectory: path.join(root, 'data'),
    integrationRoot,
    platform: 'linux',
    env: { XDG_CONFIG_HOME: config },
    homedir: root,
    exec: async () => { throw new Error('reg.exe must not run on Linux'); }
  });
  assert.deepEqual(connected, [{ browser: 'Chrome', connected: true }]);
});

test('Linux connectInstalledBrowsers registers from a Chromium profile without LOCALAPPDATA', async t => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'ad-connect-linux-'));
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  const integrationRoot = path.join(root, 'app');
  const config = path.join(root, 'config');
  const extension = path.join(integrationRoot, 'extension');
  await fs.mkdir(path.join(integrationRoot, 'integration'), { recursive: true });
  await fs.mkdir(extension, { recursive: true });
  await fs.writeFile(path.join(integrationRoot, 'integration', 'native-host'), '#!/bin/sh\n');
  await fs.writeFile(path.join(extension, 'manifest.json'), JSON.stringify({ name: 'Awesome Downloader Integration', background: { service_worker: 'background.js' } }));
  await fs.writeFile(path.join(extension, 'background.js'), "const HOST = 'com.awesome.downloader';\n");
  const profile = path.join(config, 'google-chrome', 'Default');
  await fs.mkdir(profile, { recursive: true });
  await fs.writeFile(path.join(profile, 'Preferences'), JSON.stringify({
    extensions: { settings: { abcdefghijklmnopabcdefghijklmnop: { path: extension } } }
  }));
  const connected = await connectInstalledBrowsers({
    dataDirectory: path.join(root, 'data'),
    integrationRoot,
    platform: 'linux',
    env: { XDG_CONFIG_HOME: config },
    homedir: root,
    exec: async () => { throw new Error('reg.exe must not run on Linux'); }
  });
  assert.deepEqual(connected, [{ browser: 'Chrome', connected: true }]);
});

test('firstExisting prefers a real vendor binary and can fall back to PATH', async t => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'ad-ytdlp-'));
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  const vendor = path.join(root, 'yt-dlp');
  await fs.writeFile(vendor, '#!/bin/sh\n');
  await fs.chmod(vendor, 0o755);
  assert.equal(firstExisting([path.join(root, 'missing'), vendor]), vendor);
  assert.equal(firstExisting([path.join(root, 'missing')], { env: { PATH: root }, lookupName: 'yt-dlp' }), vendor);
});

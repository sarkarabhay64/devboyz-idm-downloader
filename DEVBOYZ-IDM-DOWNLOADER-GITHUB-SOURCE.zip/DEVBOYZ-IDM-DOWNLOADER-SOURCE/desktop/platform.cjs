const path = require('node:path');
const os = require('node:os');
const { accessSync, constants } = require('node:fs');

function nativeHostFileName(platform = process.platform) {
  return platform === 'win32' ? 'native-host.exe' : 'native-host';
}

function nativeHostPath(integrationRoot, platform = process.platform) {
  return path.join(integrationRoot, 'integration', nativeHostFileName(platform));
}

function windowsNativeHostCompiler({ env = process.env } = {}) {
  return path.join(env.WINDIR || 'C:\\Windows', 'Microsoft.NET', 'Framework64', 'v4.0.30319', 'csc.exe');
}

function linuxConfigHome({ env = process.env, homedir = os.homedir() } = {}) {
  return env.XDG_CONFIG_HOME || path.join(homedir, '.config');
}

function nativeMessagingManifestDestinations(browser, { platform = process.platform, env = process.env, homedir = os.homedir() } = {}) {
  if (platform === 'win32') return [];
  const config = linuxConfigHome({ env, homedir });
  const files = {
    Chrome: [
      path.join(config, 'google-chrome', 'NativeMessagingHosts', 'com.awesome.downloader.json'),
      path.join(config, 'chromium', 'NativeMessagingHosts', 'com.awesome.downloader.json')
    ],
    Edge: [path.join(config, 'microsoft-edge', 'NativeMessagingHosts', 'com.awesome.downloader.json')],
    Firefox: [path.join(homedir, '.mozilla', 'native-messaging-hosts', 'com.awesome.downloader.json')]
  }[browser];
  return files || [];
}

function browserUserDataRoots({ platform = process.platform, env = process.env, homedir = os.homedir(), localAppData = env.LOCALAPPDATA } = {}) {
  if (platform === 'win32') {
    if (!localAppData) return [];
    return [
      { browser: 'Chrome', root: path.join(localAppData, 'Google', 'Chrome', 'User Data') },
      { browser: 'Edge', root: path.join(localAppData, 'Microsoft', 'Edge', 'User Data') }
    ];
  }
  const config = linuxConfigHome({ env, homedir });
  return [
    { browser: 'Chrome', root: path.join(config, 'google-chrome') },
    { browser: 'Chrome', root: path.join(config, 'chromium') },
    { browser: 'Edge', root: path.join(config, 'microsoft-edge') }
  ];
}

function browserExecutableCandidates(browser, { platform = process.platform, env = process.env } = {}) {
  if (platform === 'win32') {
    const relative = { Chrome: 'Google/Chrome/Application/chrome.exe', Edge: 'Microsoft/Edge/Application/msedge.exe' }[browser];
    if (!relative) return [];
    return [env.LOCALAPPDATA, env.ProgramFiles, env['ProgramFiles(x86)']].filter(Boolean).map(root => path.join(root, relative));
  }
  const names = {
    Chrome: ['google-chrome-stable', 'google-chrome', 'chromium-browser', 'chromium'],
    Edge: ['microsoft-edge-stable', 'microsoft-edge']
  }[browser] || [];
  const dirs = [...new Set([...(env.PATH || '').split(path.delimiter).filter(Boolean), '/usr/bin', '/usr/local/bin', '/snap/bin'])];
  const result = [];
  for (const dir of dirs) for (const name of names) result.push(path.join(dir, name));
  return result;
}

function openWithCommand(filePath, { platform = process.platform, env = process.env } = {}) {
  if (platform === 'win32') {
    return { command: path.join(env.SystemRoot || 'C:\\Windows', 'System32', 'OpenWith.exe'), args: [filePath] };
  }
  return { command: 'xdg-open', args: [filePath] };
}

function youtubeExtractorName(platform = process.platform) {
  return platform === 'win32' ? 'yt-dlp.exe' : 'yt-dlp';
}

function youtubeExtractorCandidates({ platform = process.platform, resourcesPath, defaultApp, electron, vendorDirectory } = {}) {
  const name = youtubeExtractorName(platform);
  const packaged = Boolean(electron && resourcesPath && !defaultApp);
  const candidates = [];
  if (packaged) candidates.push(path.join(resourcesPath, 'tools', name));
  if (vendorDirectory) candidates.push(path.join(vendorDirectory, name));
  return candidates;
}

function firstExisting(candidates, { env = process.env, lookupName } = {}) {
  for (const candidate of candidates) {
    try { accessSync(candidate, constants.F_OK); return candidate; } catch { /* try the next packaged or vendor path */ }
  }
  if (lookupName) {
    for (const dir of (env.PATH || '').split(path.delimiter).filter(Boolean)) {
      const candidate = path.join(dir, lookupName);
      try { accessSync(candidate, constants.X_OK); return candidate; } catch { /* keep searching PATH */ }
    }
  }
  return candidates[0] || lookupName;
}

function posixNativeHostScript() {
  return `#!/bin/sh
DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
RUNTIME=$(tr -d '\\r' < "$DIR/runtime-path.txt")
export ELECTRON_RUN_AS_NODE=1
exec "$RUNTIME" "$DIR/native-host.cjs"
`;
}

module.exports = {
  nativeHostFileName,
  nativeHostPath,
  windowsNativeHostCompiler,
  linuxConfigHome,
  nativeMessagingManifestDestinations,
  browserUserDataRoots,
  browserExecutableCandidates,
  openWithCommand,
  youtubeExtractorName,
  youtubeExtractorCandidates,
  firstExisting,
  posixNativeHostScript
};

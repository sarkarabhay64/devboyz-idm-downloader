---
name: Bug report
about: Report a reproducible problem without private session data
title: ''
labels: bug
assignees: ''
---

App version (for example 0.2.0-preview.1):

Operating system and architecture (Ubuntu 22.04 x64):

How you installed it (npm start, .deb, AppImage):

Browser and extension version, if relevant:

Steps to reproduce:

Expected behavior:

Actual behavior:

Remove signed media URLs, account details, cookies and tokens from screenshots
and logs. Do not attach your browser profile or `.awesome-downloader` folder.

---
name: Browser integration
about: Native messaging, extension load, or video-button issues
title: ''
labels: browser
assignees: ''
---

Desktop app version:

Operating system:

Browser and version (Chrome, Chromium, Edge, Firefox):

How the extension was loaded (Load unpacked path, store, not installed):

Does the desktop app work for a direct HTTP(S) URL without the extension?

What you expected:

What happened, including any native-host error shown in the app:

Do not attach extension IDs together with cookies, `bridge.json`, browser
profiles, or signed media URLs.

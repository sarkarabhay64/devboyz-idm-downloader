---
name: Feature request
about: Propose a capability before implementing it
title: ''
labels: enhancement
assignees: ''
---

## Problem

What is hard or missing today?

## Proposed change

Describe the user-facing behavior. Do not attach proprietary IDM materials.

## Test plan

Which operating systems and browsers can you actually verify?

Do not include tokens, signed media URLs, browser profiles, or
`.awesome-downloader` contents.

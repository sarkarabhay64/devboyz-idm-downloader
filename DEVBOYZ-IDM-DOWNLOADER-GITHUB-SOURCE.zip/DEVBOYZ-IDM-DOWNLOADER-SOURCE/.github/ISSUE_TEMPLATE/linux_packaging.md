---
name: Linux packaging
about: Problems installing or launching .deb, AppImage, or RPM builds
title: ''
labels: packaging
assignees: ''
---

Distribution and version (for example Ubuntu 22.04.5):

Architecture (amd64 / x86_64 required for current packages):

Artifact filename:

Install or launch command:

Exact error text:

FUSE available? (`libfuse2` / `fusermount` output, if AppImage):

Do not attach `/home/.../.awesome-downloader`, credentials, or private URLs.

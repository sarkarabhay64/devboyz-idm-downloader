<!-- Read docs/CONTRIBUTOR-START-HERE.md before starting new feature work. -->

## Approved issue and dependencies

Implementation issue:
Parent goal (if any):
Prerequisites and their merge/validation status:

<!-- Use Closes #N only when this PR fully completes that implementation issue.
Use Refs #N for partial work and parent goals. -->

## What changes?

## How was it tested?

- [ ] `npm test` passes
- [ ] No private URLs, cookies, tokens, browser data, or proprietary code included
- [ ] Live-browser claims are backed by live testing, not only fixtures
- [ ] Linux claims match the Ubuntu/Linux environment that was actually tested

## Known limitations

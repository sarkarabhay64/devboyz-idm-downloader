# Contributing

Issues and pull requests are welcome. DEVBOYZ IDM DOWNLOADER is an early
preview, not a finished replacement for every commercial downloader feature.

Read the [contributor start guide](docs/CONTRIBUTOR-START-HERE.md) before choosing
work. For new feature work, pick an approved issue and agree your approach with
the maintainer before coding.

## Development

Use Ubuntu 22.04 x64 and Node.js 22 or newer with npm.

```bash
npm ci
npm test
npm start
```

The legacy manual YouTube URL resolver needs the optional executable described
in THIRD-PARTY.md; the browser-capture path does not invoke it.

### Packages

| Command | Result |
| --- | --- |
| `npm run package` / `npm run package:linux` | Unpacked Linux directory |
| `npm run dist` / `npm run dist:linux` | Linux AppImage and `.deb` (x64), no publish |
| `bash scripts/build-linux.sh` | `npm ci`, tests, then Linux packages |
| `npm run dist:linux:rpm` | Linux RPM if `rpmbuild` is available (untested on Fedora/openSUSE here) |
| `npm run pack:source` | Clean GitHub-ready source ZIP |
| `npm run assemble:release` | Copy packages, ZIP, checksums, and notes into `~/Downloads/DEVBOYZ-IDM-DOWNLOADER-RELEASE/` |

These commands do not publish a release. Review [docs/RELEASING.md](docs/RELEASING.md)
before distributing binaries.

## Architecture

- `desktop/` — Electron main process, native messaging registration, platform adapters
- `core/` — download engine, HTTP, HLS, muxing, YouTube helpers
- `renderer/` — desktop UI (sandboxed, no Node integration)
- `extension/` — optional Chromium extension
- `integration/` — native host and browser bridge
- `tests/` — Node test fixtures for transfers and media helpers

Keep internal IPC channel names, the native messaging host
`com.awesome.downloader`, and the `.awesome-downloader` data directory stable
unless a change is required for correctness.

## Coding conventions

- Prefer `path.join` / `path.resolve` over hardcoded separators.
- Gate Windows-only tools (`csc.exe`, `reg.exe`, `.exe` helpers) on `process.platform === 'win32'`.
- Do not disable authentication, loopback restrictions, or URL validation to make integration easier.
- Do not claim a browser or OS is supported until it has been tested.

## Pull requests

- Link the implementation issue and identify prerequisites.
- Explain the problem, the change, and how you tested it.
- Add regressions for parsing, transfers, authentication, and lifecycle changes.
- Distinguish local fixture tests from live-browser verification.
- Keep captured URLs, cookies, tokens, browser profiles, and downloads out of Git.
- Do not include proprietary IDM code, extracted binaries, or DRM bypasses.
- Do not use `pull_request_target` to run untrusted contributor code with secrets.

By contributing, you agree to license your original contributions under the MIT
license. Third-party materials must retain compatible upstream notices.

Please be respectful. Do not post private media or session data in bug reports.
